import React from 'react'
import { useTranslation } from 'react-i18next'

export default function Contact(){
  const { t } = useTranslation()
  return (
    <section id='contact' className='py-12 px-6 max-w-3xl mx-auto'>
      <h2 className='text-3xl text-[#6fa8ff] mb-4'>{t('nav.contact')}</h2>
      <p className='text-gray-300 mb-6'>{t('footer.contact')}</p>
      <div className='bg-[#0f2636] p-6 rounded'>
        <p className='mb-3'>Phone / WhatsApp: <a href='https://wa.me/201553433336' className='text-[#6fa8ff]'>+201553433336</a></p>
        <form className='flex flex-col gap-3'>
          <input className='p-3 rounded bg-[#0b1f3a] text-white' placeholder='الاسم / Name' />
          <input className='p-3 rounded bg-[#0b1f3a] text-white' placeholder='البريد / Email' />
          <textarea className='p-3 rounded bg-[#0b1f3a] text-white' rows='4' placeholder='رسالتك / Your message'></textarea>
          <button className='mt-2 bg-[#6fa8ff] text-[#07121b] px-4 py-2 rounded'>إرسال / Send</button>
        </form>
      </div>
    </section>
  )
}
