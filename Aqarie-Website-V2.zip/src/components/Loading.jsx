import React from 'react'
import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'

export default function Loading(){
  const { t } = useTranslation()
  return (
    <div className='flex items-center justify-center min-h-screen bg-gradient-to-b from-[#07121b] to-[#0b1f3a]'>
      <motion.div initial={{opacity:0, scale:0.8}} animate={{opacity:1, scale:1}} transition={{duration:0.9}}>
        <h1 className='text-6xl font-bold text-[#6fa8ff]'>{t('loading.aq')}</h1>
      </motion.div>
    </div>
  )
}
