import React from 'react'
import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'

export default function Home(){
  const { t } = useTranslation()
  return (
    <section className='relative h-[70vh] flex items-center justify-center overflow-hidden'>
      <div className='absolute inset-0'>
        <div className='w-full h-full bg-[url(https://images.unsplash.com/photo-1505691723518-36a5a1f2d7a2?auto=format&fit=crop&w=1600&q=80)] bg-cover bg-center filter brightness-50'></div>
        <div className='absolute inset-0 bg-gradient-to-b from-transparent to-[#07121b]/90'></div>
      </div>
      <motion.div initial={{y:20, opacity:0}} animate={{y:0, opacity:1}} transition={{duration:1}} className='relative z-20 text-center px-6'>
        <h1 className='text-4xl md:text-5xl font-bold text-[#bcd8ff]'>{t('hero.title')}</h1>
        <p className='mt-4 text-lg text-gray-200 max-w-2xl mx-auto'>{t('hero.subtitle')}</p>
        <a href='#contact' className='mt-6 inline-block bg-[#6fa8ff] text-[#07121b] px-6 py-3 rounded-lg font-semibold shadow-lg'>
          {t('nav.cta')}
        </a>
      </motion.div>
    </section>
  )
}
