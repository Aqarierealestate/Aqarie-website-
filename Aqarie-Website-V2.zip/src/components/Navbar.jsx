import React from 'react'
import { useTranslation } from 'react-i18next'

export default function Navbar(){
  const { t, i18n } = useTranslation()
  const toggle = ()=> i18n.changeLanguage(i18n.language === 'ar' ? 'en' : 'ar')
  return (
    <nav className='fixed top-0 left-0 right-0 bg-[#07121b]/80 backdrop-blur z-40'>
      <div className='max-w-6xl mx-auto px-6 py-4 flex items-center justify-between'>
        <div className='text-2xl font-bold text-[#6fa8ff]'>A.Q</div>
        <div className='flex items-center gap-6'>
          <a href='#' className='hover:text-[#6fa8ff]'>{t('nav.home')}</a>
          <a href='#' className='hover:text-[#6fa8ff]'>{t('nav.about')}</a>
          <a href='#' className='hover:text-[#6fa8ff]'>{t('nav.services')}</a>
          <a href='#' className='hover:text-[#6fa8ff]'>{t('nav.projects')}</a>
          <a href='#' className='hover:text-[#6fa8ff]'>{t('nav.testimonials')}</a>
          <a href='#' className='hover:text-[#6fa8ff]'>{t('nav.contact')}</a>
          <button onClick={toggle} className='border border-[#6fa8ff] px-3 py-1 rounded text-[#6fa8ff] hover:bg-[#6fa8ff] hover:text-[#07121b]'>
            {t('nav.lang')}
          </button>
        </div>
      </div>
    </nav>
  )
}
