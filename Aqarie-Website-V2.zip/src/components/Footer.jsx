import React from 'react'
import { useTranslation } from 'react-i18next'

export default function Footer(){
  const { t } = useTranslation()
  return (
    <footer className='bg-[#07121b] py-6 mt-12 text-center text-[#9cb8e5]'>
      <div className='max-w-6xl mx-auto px-6'>
        <p>{t('footer.rights')}</p>
        <p className='mt-2'><a href='https://wa.me/201553433336' className='text-[#6fa8ff]'>+201553433336</a></p>
      </div>
    </footer>
  )
}
