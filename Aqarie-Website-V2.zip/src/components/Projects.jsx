import React from 'react'
import { useTranslation } from 'react-i18next'
import { motion } from 'framer-motion'

const items = [
  {id:1, title_ar:'مشروع البستان', title_en:'Al Bostan Project', img:'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80'},
  {id:2, title_ar:'برج النخبة', title_en:'Elite Tower', img:'https://images.unsplash.com/photo-1493558103817-58b2924bce98?auto=format&fit=crop&w=800&q=80'},
  {id:3, title_ar:'كمباوند الربيع', title_en:'Spring Compound', img:'https://images.unsplash.com/photo-1505691723518-36a5a1f2d7a2?auto=format&fit=crop&w=800&q=80'},
]

export default function Projects(){
  const { t, i18n } = useTranslation()
  return (
    <section id='projects' className='py-12 px-6 max-w-6xl mx-auto'>
      <h2 className='text-3xl text-[#6fa8ff] mb-4'>{t('projects.title')}</h2>
      <p className='text-gray-300 mb-6'>{t('projects.desc')}</p>
      <div className='grid md:grid-cols-3 gap-6'>
        {items.map(it=>(
          <motion.div key={it.id} whileHover={{scale:1.02}} className='bg-[#0f2b3f] rounded overflow-hidden shadow-lg'>
            <img src={it.img} alt='' className='w-full h-44 object-cover' />
            <div className='p-4'>
              <h3 className='text-xl text-[#bcd8ff]'>{i18n.language==='ar' ? it.title_ar : it.title_en}</h3>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
