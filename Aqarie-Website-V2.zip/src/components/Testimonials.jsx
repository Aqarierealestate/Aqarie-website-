import React from 'react'
import { useTranslation } from 'react-i18next'
import { motion } from 'framer-motion'

export default function Testimonials(){
  const { t, i18n } = useTranslation()
  const items = t('testimonials.items', {returnObjects: true})
  return (
    <section id='testimonials' className='py-12 px-6 max-w-4xl mx-auto'>
      <h2 className='text-3xl text-[#6fa8ff] mb-6'>{t('testimonials.title')}</h2>
      <div className='grid md:grid-cols-3 gap-6'>
        {items.map((it,idx)=>(
          <motion.div key={idx} whileHover={{y:-5}} className='bg-[#0f2636] p-6 rounded shadow'>
            <p className='text-gray-200'>"{it}"</p>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
