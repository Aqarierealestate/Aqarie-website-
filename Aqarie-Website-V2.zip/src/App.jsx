import React, { useState, useEffect } from 'react'
import Navbar from './components/Navbar'
import Loading from './components/Loading'
import Home from './components/Home'
import Projects from './components/Projects'
import Testimonials from './components/Testimonials'
import Contact from './components/Contact'
import Footer from './components/Footer'

export default function App(){
  const [loading, setLoading] = useState(true)
  useEffect(()=>{ const t = setTimeout(()=> setLoading(false), 2000); return ()=> clearTimeout(t) },[])
  return loading ? <Loading /> : (
    <div className='min-h-screen'>
      <Navbar />
      <main className='pt-24'>
        <Home />
        <Projects />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
      <a href='https://wa.me/201553433336' target='_blank' rel='noreferrer' className='fixed bottom-6 left-6 bg-green-500 p-4 rounded-full shadow-lg'>
        <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='white'><path d='M20.52 3.478A11.933 11.933 0 0 0 12 0C5.373 0 .02 5.373.02 12c0 2.11.55 4.105 1.6 5.88L0 24l6.26-1.64A11.92 11.92 0 0 0 12 24c6.627 0 12-5.373 12-12 0-1.8-.36-3.5-1.48-5.04z'/></svg>
      </a>
    </div>
  )
}
