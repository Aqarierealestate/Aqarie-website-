# Aqarie-Website-V2

نسخة A.Q / Aqarie – Real Estate Solutions جاهزة للنشر (Vite + React + Tailwind)

## المحتوى
- الصفحة الرئيسية، من نحن، الخدمات، المشاريع، آراء العملاء، تواصل معنا
- ثنائي اللغة (ar / en)
- زر واتساب مباشر: +201553433336
- شاشة تحميل تظهر 'A.Q' لمدة ثانيتين
- فوتر مع حقوق الملكية: © 2025 Aqarie Real Estate Solutions. All rights reserved.

## التشغيل محليًا
1. فك الضغط وادخل المجلد:
   ```
   cd Aqarie-Website-V2
   ```
2. ثبت الحزم:
   ```
   npm install
   ```
3. شغّل بيئة التطوير:
   ```
   npm run dev
   ```
4. افتح المتصفح على الرابط الذي يظهر (عادة http://localhost:5173)

## البناء والرفع (Vercel - موصى به)
1. ارفع الكود على GitHub ثم اربطه بـ Vercel.
2. Build Command: `npm run build`
3. Output Directory: `dist`

## رفع مباشر من الموبايل (خلاصة)
- افك الضغط على الجهاز.
- افتح GitHub عبر المتصفح (Desktop view).
- أنشئ Repository جديد.
- Use "Add file → Upload files" لرفع ملفات المشروع.
- بعد الرفع، ادخل Vercel واختر New Project → اختر المستودع → Deploy.

## تعديل المحتوى
- النصوص الثنائية: `src/locales/ar.json`, `src/locales/en.json`
- صور المشاريع: في مكونات Projects تشير لروابط Unsplash، استبدلها بملفاتك أو ارفع صور في `src/assets`
- رقم الواتساب: في `src/App.jsx` (رابط) و`src/components/Contact.jsx` و`src/components/Footer.jsx`

بالتوفيق! لو تحب أرفع لك المشروع على GitHub خطوة بخطوة من الموبايل، قول لي "ابدأ الرفع" وأنا أشرح كل ضغطة.
