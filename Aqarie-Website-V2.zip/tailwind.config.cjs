module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        aqarieDark: '#07121b',
        aqarieBlue: '#0b1f3a',
        aqarieMid: '#132939',
        aqarieAccent: '#6fa8ff'
      },
      fontFamily: {
        cairo: ['Cairo', 'sans-serif'],
        tajawal: ['Tajawal', 'sans-serif']
      }
    },
  },
  plugins: [],
}
